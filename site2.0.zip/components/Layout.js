export default function Layout({ children }){
  return (
    <div className="container">
      <nav className="nav">
        <a className="brand" href="/">Site 2.0</a>
        <a href="/">Home</a>
        <a href="/about">About</a>
        <a href="/firefighter">Firefighter</a>
        <a href="/police">Police</a>
        <a href="/evansville">Evansville</a>
      </nav>
      {children}
      <footer className="footer muted">© {new Date().getFullYear()} Site 2.0</footer>
    </div>
  );
}

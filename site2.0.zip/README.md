# Site 2.0 (Next.js)

**What’s included**
- News on top, Writings below.
- Under News: links + descriptions for Firefighter, Police, Evansville.
- `/about` with a 4000+ word absurdist fantasy loaded from `public/about/about.txt` (so the repo stays light).
- All static assets in `/public` (including `headshot.png`).

## Quickstart
```bash
npm install
npm run dev
# open http://localhost:3000
```
## Build
```bash
npm run build
npm start
```

## Replace the Headshot
Swap `/public/headshot.png` with your real image (same filename).

## Edit Story
Edit the long story at: `public/about/about.txt`. The About page fetches it from `/about/about.txt`.

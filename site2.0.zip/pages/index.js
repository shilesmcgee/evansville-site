import Layout from "@/components/Layout";

const news = [
  { title: "City Council accidentally approves intergalactic taco stand", href: "#", date: "2025-08-01" },
  { title: "Quiet Tuesday disrupted by mysterious sky ripple over the river", href: "#", date: "2025-07-29" },
  { title: "Library reports record chess games; blames time travelers", href: "#", date: "2025-07-20" },
];

const writings = [
  { title: "Notes on Unscheduled Heroics (not heroic)", href: "#" },
  { title: "How To Fold Space With A Laundry Basket", href: "#" },
  { title: "Pacers Playbook Scribbled On A Napkin", href: "#" },
];

export default function Home(){
  return (
    <Layout>
      <section className="hero">
        <h1>News</h1>
        <p className="muted">Latest bits, right on top. Writings are below, as requested.</p>
        <div className="section">
          <ul className="list">
            {news.map((n) => (
              <li key={n.title}>
                <a href={n.href}>{n.title}</a> <span className="muted">({n.date})</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="section">
          <h2>Quick Links</h2>
          <p className="muted">Per your spec: firefighter, police, and Evansville appear under News with short descriptions.</p>
          <div className="grid">
            <div className="card">
              <h3><a href="/firefighter">Firefighter</a></h3>
              <p className="muted">Notes from the nights where the fire knew my name but respected the mustache.</p>
            </div>
            <div className="card">
              <h3><a href="/police">Police</a></h3>
              <p className="muted">Foot patrols where the pavement told stories louder than the radios.</p>
            </div>
            <div className="card">
              <h3><a href="/evansville">Evansville</a></h3>
              <p className="muted">The river bends, the wind changes, and every diner booth is a witness stand.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <h2>Writings</h2>
        <ul className="list">
          {writings.map((w) => (
            <li key={w.title}>
              <a href={w.href}>{w.title}</a>
            </li>
          ))}
        </ul>
      </section>
    </Layout>
  );
}

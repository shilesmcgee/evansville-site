import Layout from "@/components/Layout";

export default function Firefighter(){
  return (
    <Layout>
      <section className="section">
        <h1>Firefighter</h1>
        <p className="muted">Brief description under News linked here; this page expands on the craft.</p>
        <p>Some nights the siren arrived before the smoke. Some nights the radio felt like it was whispering our names. The work is simple: show up, stay calm, read a room that’s on fire, make it look like water and timing were always enough.</p>
        <ul className="list">
          <li>Vent, enter, search — never in that order twice.</li>
          <li>Check your partner’s eyes, then their air, then your pride.</li>
          <li>Hot doors tell the truth faster than people.</li>
        </ul>
      </section>
    </Layout>
  );
}

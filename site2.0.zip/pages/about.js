import { useEffect, useState } from 'react';
import Layout from '@/components/Layout';

export default function About(){
  const [text, setText] = useState('Loading story...');
  useEffect(() => {
    fetch('/about/about.txt')
      .then(r => r.text())
      .then(t => setText(t))
      .catch(() => setText('Could not load the story. Make sure /public/about/about.txt exists.'));
  }, []);

  return (
    <Layout>
      <section className="section">
        <h1>About Me</h1>
        <p className="muted">Absurdist autobiography (4000+ words) featuring aliens, mobsters, the Red Sox, the Pacers, Michael Jordan, and a certain unmarked grave.</p>
        <img src="/headshot.png" alt="Headshot" width="320" height="320" />
        <article className="pre" style={{marginTop:12}}>{text}</article>
      </section>
    </Layout>
  );
}

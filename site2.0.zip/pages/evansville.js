import Layout from "@/components/Layout";

export default function Evansville(){
  return (
    <Layout>
      <section className="section">
        <h1>Evansville</h1>
        <p className="muted">A few slices from the river city that keeps score in stories.</p>
        <p>Evansville is where the wind runs drills with the Ohio River and the street grid respects the stubborn. You don’t ask for directions; you ask for memories. Everyone’s got a compass that points to a diner booth and a high school gym.</p>
        <ul className="list">
          <li>The old mill whistle is now a ringtone, but people still look up.</li>
          <li>Pickups idle outside sudden parades.</li>
          <li>Basketball hoops inherit the weather and return it in the fourth quarter.</li>
        </ul>
      </section>
    </Layout>
  );
}

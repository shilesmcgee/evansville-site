import Layout from "@/components/Layout";

export default function Police(){
  return (
    <Layout>
      <section className="section">
        <h1>Police</h1>
        <p className="muted">Brief description under News linked here; this page adds the texture.</p>
        <p>Walking a block at 3 a.m. teaches you more about physics and people than any lecture ever could. Gravity pulls on secrets. You see where they settle — porch lights, corner lots, the fence that always rattles one second too late.</p>
        <ul className="list">
          <li>Most fights end with someone offering coffee.</li>
          <li>Write the report as if the pavement can read.</li>
          <li>Silence is surveillance without the paperwork.</li>
        </ul>
      </section>
    </Layout>
  );
}
